<nav class="sidebar-nav scroll-sidebar" data-simplebar="">
    <ul id="sidebarnav">
        
        
        <?php if(Auth::user()->id_role == '1'): ?>
        
        <!-- Dashboard Section -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Menu Utama</span>
        </li>
        
        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="ti ti-layout-dashboard"></i>
                </span>
                <span class="hide-menu">Dashboard</span>
            </a>
        </li>

        <!-- Konten Section -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Manajemen</span>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('kategori.*') ? 'active' : ''); ?>" href="<?php echo e(route('kategori.index')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-bookmark-star"></i>
                </span>
                <span class="hide-menu">Kategori</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('vendor.*') ? 'active' : ''); ?>" href="<?php echo e(route('vendor.index')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-building-check"></i>
                </span>
                <span class="hide-menu">Vendor</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('kelas.*') ? 'active' : ''); ?>" href="<?php echo e(route('kelas.index')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-journal-bookmark"></i>
                </span>
                <span class="hide-menu">Kelas</span>
                <?php
                    $kelasAktif = \App\Models\Kelas::where('status', 'Aktif')->count();
                ?>
                <?php if($kelasAktif > 0): ?>
                <span class="sidebar-badge bg-success"><?php echo e($kelasAktif); ?></span>
                <?php endif; ?>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('transaksi.*') ? 'active' : ''); ?>" href="<?php echo e(route('transaksi.index')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-credit-card-2-front"></i>
                </span>
                <span class="hide-menu">Transaksi</span>
                <?php
                    $pendingTrans = \App\Models\Transaksi::where('status_pembayaran', 'pending')->count();
                ?>
                <?php if($pendingTrans > 0): ?>
                <span class="sidebar-badge bg-warning"><?php echo e($pendingTrans); ?></span>
                <?php endif; ?>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('peserta.*') ? 'active' : ''); ?>" href="<?php echo e(route('peserta.index')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-people"></i>
                </span>
                <span class="hide-menu">Peserta</span>
            </a>
        </li>

        <!-- User Management -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Pengguna</span>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('user.*') && !request()->routeIs('user.profile') ? 'active' : ''); ?>" href="<?php echo e(route('user.index')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-person-gear"></i>
                </span>
                <span class="hide-menu">Kelola Pengguna</span>
            </a>
        </li>

        <!-- Account Section (Admin) -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Akun</span>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('user.profile') ? 'active' : ''); ?>" href="<?php echo e(route('user.profile')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-person-circle"></i>
                </span>
                <span class="hide-menu">Profil Saya</span>
            </a>
        </li>

        <!-- Reports Section -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Laporan</span>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('peserta.cetak')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-printer"></i>
                </span>
                <span class="hide-menu">Cetak Peserta</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('transaksi.cetaksuccess')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-file-earmark-text"></i>
                </span>
                <span class="hide-menu">Laporan Transaksi</span>
            </a>
        </li>

        
        <?php else: ?>
        
        <!-- Dashboard Section -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Menu Utama</span>
        </li>
        
        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="ti ti-layout-dashboard"></i>
                </span>
                <span class="hide-menu">Dashboard</span>
            </a>
        </li>

        <!-- Kelas Section -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Pembelajaran</span>
        </li>
        
        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('kelas.userIndex') ? 'active' : ''); ?>" href="<?php echo e(route('kelas.userIndex')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-journal-bookmark"></i>
                </span>
                <span class="hide-menu">Daftar Kelas</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('myclass.userIndex') ? 'active' : ''); ?>" href="<?php echo e(route('myclass.userIndex')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-mortarboard"></i>
                </span>
                <span class="hide-menu">Kelas Saya</span>
                <?php
                    $myClassCount = \App\Models\Myclass::where('user_id', Auth::id())->count();
                ?>
                <?php if($myClassCount > 0): ?>
                <span class="sidebar-badge bg-primary"><?php echo e($myClassCount); ?></span>
                <?php endif; ?>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('learn.*') ? 'active' : ''); ?>" href="<?php echo e(route('learn.index')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-play-circle"></i>
                </span>
                <span class="hide-menu">Mulai Belajar</span>
                <?php
                    $activeClassCount = \App\Models\Myclass::where('user_id', Auth::id())->where('status', 'Aktif')->count();
                ?>
                <?php if($activeClassCount > 0): ?>
                <span class="sidebar-badge bg-success"><?php echo e($activeClassCount); ?></span>
                <?php endif; ?>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('certificates.*') ? 'active' : ''); ?>" href="<?php echo e(route('certificates.index')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-award"></i>
                </span>
                <span class="hide-menu">Sertifikat Saya</span>
                <?php
                    $certCount = \App\Models\Certificate::where('user_id', Auth::id())->count();
                ?>
                <?php if($certCount > 0): ?>
                <span class="sidebar-badge bg-warning"><?php echo e($certCount); ?></span>
                <?php endif; ?>
            </a>
        </li>

        <!-- Profile Section -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Akun</span>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link <?php echo e(request()->routeIs('user.profile') ? 'active' : ''); ?>" href="<?php echo e(route('user.profile')); ?>" aria-expanded="false">
                <span class="sidebar-icon">
                    <i class="bi bi-person-circle"></i>
                </span>
                <span class="hide-menu">Profil Saya</span>
            </a>
        </li>
        
        <?php endif; ?>
        
    </ul>
</nav>
<!-- End Sidebar navigation --><?php /**PATH C:\laragon\www\siskav2\resources\views/dashboard/sidebar.blade.php ENDPATH**/ ?>
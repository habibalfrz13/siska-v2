<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SISKAE - Pusat Sertifikasi & Kompetensi Keahlian Digital</title>
  <meta content="Tingkatkan karir Anda dengan sertifikasi ahli dan kursus kompetensi digital di SISKAE. Belajar dari ahli, raih masa depan cerah." name="description">
  <meta content="sertifikasi, kursus online, kompetensi keahlian, pelatihan kerja, digital skills, SISKAE" name="keywords">
  <meta name="author" content="SISKAE Team">
  
  <meta property="og:title" content="SISKAE - Sertifikasi & Kompetensi Keahlian">
  <meta property="og:description" content="Platform pengembangan skill terbaik untuk masa depan karir Anda.">
  <meta property="og:image" content="<?php echo e(asset('template/frontend/img/hero-img.png')); ?>">
  <meta property="og:url" content="<?php echo e(url('/')); ?>">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="preconnect" href="https://api.openweathermap.org">

  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <link href="<?php echo e(asset('template/frontend/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/frontend/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/frontend/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/frontend/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/frontend/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/frontend/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">

  <link href="<?php echo e(asset('template/frontend/css/style.css')); ?>" rel="stylesheet">

  <style>
    :root {
      --primary-color: #4154f1;
      --secondary-color: #2c384e;
      --accent-color: #012970;
      --bg-gradient: linear-gradient(120deg, #f6f9ff 0%, #eef2f3 100%);
    }

    body {
      font-family: 'Nunito', sans-serif;
      background: #fdfdfd;
      color: #444444;
    }

    /* Navbar Glass Effect */
    .header {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(10px);
      box-shadow: 0px 2px 20px rgba(1, 41, 112, 0.1);
    }

    /* Hero Section Enhancements */
    #hero {
      background: url("<?php echo e(asset('template/frontend/img/hero-bg.png')); ?>") top center no-repeat;
      background-size: cover;
      padding-top: 120px;
    }
    .hero h1 {
      font-weight: 800;
      color: var(--accent-color);
    }
    .btn-get-started {
      background: var(--primary-color);
      border-radius: 50px;
      padding: 12px 40px;
      box-shadow: 0 8px 28px rgba(65, 84, 241, 0.45);
      transition: all 0.3s ease;
    }
    .btn-get-started:hover {
      transform: translateY(-3px);
      box-shadow: 0 12px 30px rgba(65, 84, 241, 0.6);
    }

    /* Card Modernization */
    .card {
      border: none;
      border-radius: 15px;
      background: #fff;
      box-shadow: 0 10px 30px rgba(0,0,0,0.08);
      transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
      overflow: hidden;
    }
    .card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 35px rgba(65, 84, 241, 0.15);
    }
    .card-img-top {
      transition: transform 0.5s ease;
    }
    .card:hover .card-img-top {
      transform: scale(1.05);
    }
    .card-title {
      font-weight: 700;
      color: var(--accent-color);
    }

    /* Weather Widget Styling */
    .weather-card {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 15px;
      padding: 20px;
      margin-top: 20px;
    }
    .weather-icon { font-size: 2rem; margin-bottom: 10px; }
    .weather-data-item { text-align: center; border-right: 1px solid rgba(255,255,255,0.2); }
    .weather-data-item:last-child { border-right: none; }
    
    /* Loading Skeleton for Weather */
    .skeleton {
      background: rgba(255,255,255,0.2);
      height: 20px;
      border-radius: 4px;
      animation: pulse 1.5s infinite;
    }
    @keyframes pulse { 0% { opacity: 0.6; } 50% { opacity: 1; } 100% { opacity: 0.6; } }

    /* Footer Modernization */
    .footer { background: #f6f9ff; padding-top: 50px; }
    .footer h3 { font-weight: 800; color: var(--accent-color); }
  </style>
</head>

<body>

  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="<?php echo e(url('/')); ?>" class="logo d-flex align-items-center text-decoration-none">
        <img src="<?php echo e(asset('template/frontend/img/logo.png')); ?>" alt="Logo SISKAE" width="40" height="40">
        <span style="font-family: 'Poppins', sans-serif;">SISKAE</span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Beranda</a></li>
          <li><a class="nav-link scrollto" href="#about">Tentang</a></li>
          <li><a class="nav-link scrollto" href="#classes">Kelas</a></li>
          <li><a class="getstarted scrollto" href="<?php echo e(route('login')); ?>">Masuk / Daftar</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>

    </div>
  </header>

  <section id="hero" class="hero d-flex align-items-center">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up">Tingkatkan Skill,<br>Raih Masa Depan</h1>
          <h2 data-aos="fade-up" data-aos-delay="400" class="mt-3">Platform sertifikasi dan pelatihan kompetensi digital terdepan untuk profesional modern.</h2>
          <div data-aos="fade-up" data-aos-delay="600">
            <div class="text-center text-lg-start mt-4">
              <a href="#classes" class="btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center text-decoration-none">
                <span>Lihat Kursus</span>
                <i class="bi bi-arrow-right ms-2"></i>
              </a>
            </div>
          </div>
        </div>
        <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
          <img src="<?php echo e(asset('template/frontend/img/hero-img.png')); ?>" class="img-fluid" alt="Ilustrasi Edukasi Digital" loading="eager">
        </div>
      </div>
    </div>
  </section>

  <main id="main">

    <section id="about" class="about section-bg">
      <div class="container" data-aos="fade-up">
        <div class="row gx-5">
          <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-right" data-aos-delay="200">
             <div class="image-wrapper position-relative">
                <img src="<?php echo e(asset('template/frontend/img/about.jpg')); ?>" class="img-fluid rounded-4 shadow-lg" alt="Tentang SISKAE" loading="lazy">
             </div>
          </div>
          <div class="col-lg-6 d-flex flex-column justify-content-center" data-aos="fade-left" data-aos-delay="400">
            <div class="content ps-0 ps-lg-5">
              <span class="text-uppercase text-primary fw-bold small">Tentang Kami</span>
              <h3 class="fw-bold mb-3">Membangun Kompetensi, Menciptakan Peluang.</h3>
              <p class="text-muted">
                SISKAE hadir sebagai jembatan antara dunia pendidikan dan kebutuhan industri. Kami menyediakan kurikulum yang relevan dengan standar industri terkini.
              </p>
              <div class="row mt-4">
                <div class="col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="100">
                  <i class="ri-award-line text-primary fs-3 mb-2"></i>
                  <h4 class="fw-bold">Sertifikasi Resmi</h4>
                  <p class="small text-muted">Dapatkan pengakuan atas keahlian Anda dengan sertifikat tervalidasi.</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="200">
                  <i class="ri-rocket-line text-primary fs-3 mb-2"></i>
                  <h4 class="fw-bold">Mentor Praktisi</h4>
                  <p class="small text-muted">Belajar langsung dari para ahli yang berpengalaman di bidangnya.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="classes" class="classes section-bg">
      <div class="container" data-aos="fade-up">
          <header class="section-header text-center mb-5">
              <p class="text-uppercase text-primary fw-bold small">Katalog Kelas</p>
              <h2 class="fw-bold display-6">Pilihan Kelas Populer</h2>
          </header>

          <div class="row gy-4">
              <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo e($loop->iteration * 100); ?>">
                  <div class="card h-100 border-0 shadow-sm">
                      <div class="position-relative overflow-hidden">
                        <img src="<?php echo e(url('images/galerikelas/' . $class->foto)); ?>" class="card-img-top" alt="<?php echo e($class->judul); ?>" style="height: 220px; object-fit: cover;" loading="lazy">
                        <div class="position-absolute top-0 end-0 m-3 px-3 py-1 bg-white rounded-pill shadow-sm small fw-bold text-primary">
                            Online
                        </div>
                      </div>
                      <div class="card-body d-flex flex-column p-4">
                          <h5 class="card-title mb-3"><?php echo e($class->judul); ?></h5>
                          <p class="card-text text-muted small flex-grow-1">
                            <?php echo e(Str::limit(strip_tags($class->deskripsi), 100)); ?>

                          </p>
                          <div class="d-grid mt-3">
                              <a href="<?php echo e(route('login')); ?>" class="btn btn-primary rounded-pill py-2">Daftar Sekarang</a>
                          </div>
                      </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="col-12 text-center py-5">
                  <p class="text-muted">Belum ada kelas yang tersedia saat ini.</p>
              </div>
              <?php endif; ?>
          </div>
      </div>
    </section>

  </main>

  <footer id="footer" class="footer mt-auto">

    <div class="container">
      <div class="row gy-4">
        
        <div class="col-lg-5 col-md-12 footer-info">
          <a href="<?php echo e(url('/')); ?>" class="logo d-flex align-items-center mb-3 text-decoration-none">
            <img src="<?php echo e(asset('template/frontend/img/logo.png')); ?>" alt="" width="40">
            <span class="ms-2 fs-4 fw-bold text-dark">SISKAE</span>
          </a>
          <p class="text-muted small">
            Platform edukasi digital yang berdedikasi untuk mencetak talenta digital berkualitas tinggi. Bersama SISKAE, wujudkan karir impian Anda melalui pembelajaran yang terstruktur dan aplikatif.
          </p>
          <div class="social-links mt-3">
            <a href="#" class="twitter rounded-circle bg-light text-primary"><i class="bi bi-twitter"></i></a>
            <a href="#" class="facebook rounded-circle bg-light text-primary"><i class="bi bi-facebook"></i></a>
            <a href="#" class="instagram rounded-circle bg-light text-primary"><i class="bi bi-instagram"></i></a>
            <a href="#" class="linkedin rounded-circle bg-light text-primary"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 footer-contact text-center text-md-start">
          <h4 class="fw-bold mb-3">Cuaca Lokal (Padang)</h4>
          <div class="weather-card shadow-lg" id="weather-box">
             <div class="d-flex justify-content-between align-items-center mb-2">
                <div>
                   <h2 class="mb-0 fw-bold" id="temperature">--&deg;C</h2>
                   <p class="mb-0 small" id="description">Memuat data...</p>
                </div>
                <div class="text-end">
                   <i class="bi bi-cloud-sun fs-1" id="weather-main-icon"></i>
                </div>
             </div>
             <hr class="bg-white opacity-25">
             <div class="row g-0">
                <div class="col-6 weather-data-item">
                   <i class="bi bi-wind"></i> <span id="wind-speed">--</span> m/s
                </div>
                <div class="col-6 weather-data-item">
                   <i class="bi bi-droplet-fill"></i> <span id="humidity">--</span> %
                </div>
             </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 footer-links">
          <h4 class="fw-bold">Tautan Cepat</h4>
          <ul class="list-unstyled">
            <li class="mb-2"><i class="bi bi-chevron-right text-primary me-2"></i> <a href="#hero" class="text-decoration-none text-muted">Beranda</a></li>
            <li class="mb-2"><i class="bi bi-chevron-right text-primary me-2"></i> <a href="#about" class="text-decoration-none text-muted">Tentang Kami</a></li>
            <li class="mb-2"><i class="bi bi-chevron-right text-primary me-2"></i> <a href="#classes" class="text-decoration-none text-muted">Kelas</a></li>
            <li class="mb-2"><i class="bi bi-chevron-right text-primary me-2"></i> <a href="<?php echo e(route('login')); ?>" class="text-decoration-none text-muted">Login Member</a></li>
          </ul>
        </div>

      </div>
    </div>
    
    <div class="container mt-4">
      <div class="copyright text-center small text-muted">
        &copy; <?php echo e(date('Y')); ?> <strong><span>SISKAE</span></strong>. All Rights Reserved.
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center bg-primary rounded-circle shadow"><i class="bi bi-arrow-up-short text-white"></i></a>

  <script src="<?php echo e(asset('template/frontend/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('template/frontend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/frontend/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/frontend/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/frontend/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
  
  <script src="<?php echo e(asset('template/frontend/js/main.js')); ?>"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Inisialisasi AOS
        AOS.init({
            duration: 1000,
            easing: 'ease-in-out',
            once: true,
            mirror: false
        });

        // Weather API Logic
        const apiKey = '2bb008a2dee92d080615c7975ccf5bfa'; // Note: Sebaiknya API Key disimpan di .env dan dipanggil via backend proxy untuk keamanan
        const city = 'Padang';
        const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=id`;

        const weatherBox = document.getElementById('weather-box');

        fetch(apiUrl)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            // Update UI
            document.getElementById('temperature').innerHTML = `${Math.round(data.main.temp)}&deg;C`;
            document.getElementById('humidity').textContent = data.main.humidity;
            document.getElementById('wind-speed').textContent = data.wind.speed;
            
            // Capitalize description
            const desc = data.weather[0].description;
            document.getElementById('description').textContent = desc.charAt(0).toUpperCase() + desc.slice(1);
            
            // Dynamic Icon based on weather condition
            const iconCode = data.weather[0].icon;
            const iconUrl = `http://openweathermap.org/img/wn/${iconCode}@2x.png`;
            // Mengganti icon bootstrap dengan gambar asli dari API atau mapping manual
            document.getElementById('weather-main-icon').className = ''; // Reset class
            document.getElementById('weather-main-icon').innerHTML = `<img src="${iconUrl}" alt="Weather Icon" width="50">`;
        })
        .catch(error => {
            console.error('Error fetching weather:', error);
            document.getElementById('description').textContent = "Gagal memuat cuaca.";
        });
    });
  </script>

</body>
</html><?php /**PATH C:\laragon\www\siska\resources\views/welcome.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="container-fluid">
    <div class="card mb-0">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col">
                    <h5 class="card-title fw-semibold mb-4 d-inline">Transaksi Management</h5>
                </div>
                <div class="col d-flex justify-content-end">
                    <a href="<?php echo e(route('transaksi.cetak')); ?>" class="btn btn-sm btn-warning mx-1"><i class="bi bi-printer"></i> Cetak</a>
                    <a href="<?php echo e(route('transaksi.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus"></i> Buat Transaksi</a>
                </div>
            </div>
            <table class="table table-striped" style="width:100%" id="example">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pengguna</th>
                        <th>Nama Kelas</th>
                        <th>Jumlah</th>
                        <th>Status Pembayaran</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($transaksi->user->biodata->username); ?></td>
                        <td><?php echo e($transaksi->kelas->judul); ?></td>
                        <td><?php echo e($transaksi->jumlah_pembayaran); ?></td>
                        <td><?php echo e($transaksi->status_pembayaran); ?></td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/transaksi/index.blade.php ENDPATH**/ ?>
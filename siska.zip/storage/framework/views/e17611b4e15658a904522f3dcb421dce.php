

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php if($myclass->isEmpty()): ?>
        <div class="col-lg-12 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">Anda Belum Mengikuti Kelas Apapun</h5>
                </div>
            </div>
        </div>
        <?php else: ?>
            <?php $__currentLoopData = $myclass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                 $data = App\Models\Kelas::where('id', $class->kelas_id)->first();
            ?>
            <div class="col-lg-4 mb-4">
                <div class="card shadow-sm h-100">
                    <img src="<?php echo e(url('images/galerikelas/'.$class->kelas->foto )); ?>" class="card-img-top img-fluid" style="height: 200px;" alt="Foto Kelas">
                    
                    
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($class->kelas->judul); ?></h5>
                        <p class="card-text">Waktu Pelaksanaan: <?php echo e(\Carbon\Carbon::parse($class->kelas->pelaksanaan)->format('d M Y')); ?></p>
                        <p class="card-text">Status: <?php echo e($class->status); ?></p>
                        <div class="d-flex justify-content-between">
                            <?php if($class->status == 'Aktif'): ?>
                                <a href="<?php echo e(route('myclass.userIndexDetail')); ?>" class="btn btn-success">GoToClass</a>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($class->id_kelas); ?>">Detail</button>
                            <?php elseif($class->status == 'Tidak Aktif'): ?>
                                <a href="<?php echo e(route('transaksi.userIndex', $class->id )); ?>" class="btn btn-warning">Pembayaran</a>
                            <?php elseif($class->status == 'Pending'): ?>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($class->id_kelas); ?>">Detail</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal for deleting class -->
            <div class="modal fade" id="hapusModal<?php echo e($class->id_kelas); ?>" tabindex="-1" aria-labelledby="hapusModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="hapusModalLabel">Hapus Kelas</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Apakah Anda yakin ingin menghapus kelas ini?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
                            <form action="<?php echo e(route('myclass.destroy', $class->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal for detail -->
            <div class="modal fade" id="detailModal<?php echo e($class->id_kelas); ?>" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="detailModalLabel">Detail Kelas</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <!-- Your class details go here -->
                            <p>Judul Kelas: <?php echo e($class->kelas->judul); ?></p>
                            <p>Kuota: <?php echo e($class->kelas->kuota); ?></p>
                            <p>Status: <?php echo e($class->status); ?></p>
                            <!-- End of class details -->
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/myclass/userIndex.blade.php ENDPATH**/ ?>
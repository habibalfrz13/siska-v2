

<?php $__env->startSection('content'); ?>
    <div class="row p-2">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Show User</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('user.index')); ?>">Back</a>
            </div>
        </div>
    </div>

    <div class="card border-info shadow-lg">
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <strong>Name:</strong>
                        <?php echo e($user->name); ?>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <strong>Username:</strong>
                        <?php echo e($user->username); ?>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <strong>Email:</strong>
                        <?php echo e($user->email); ?>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <strong>Jenis Kelamin:</strong>
                        <?php echo e($user->jenis_kelamin ?: 'Not specified'); ?>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <strong>Bio:</strong>
                        <?php echo e($user->bio ?: 'Not specified'); ?>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <strong>Nomor Telepon:</strong>
                        <?php echo e($user->nomor_hp ?: 'Not specified'); ?>

                    </div>
                </div>

                <div class="col-md-12 text-center">
                    <div class="form-group">
                        <strong>Foto:</strong>
                        <?php if($user->foto): ?>
                            <img src="<?php echo e(Storage::url('user/' . $user->foto)); ?>" class="img-fluid rounded" alt="User Photo" style="max-width: 100%; max-height: 200px;">
                        <?php else: ?>
                            <div class="text-muted">No photo available</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/user/show.blade.php ENDPATH**/ ?>
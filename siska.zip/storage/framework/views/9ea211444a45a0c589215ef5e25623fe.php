

<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 margin-tb">
                            <div class="pull-left">
                                <h2>Edit User</h2>
                            </div>
                            <div class="pull-right">
                                <a class="btn btn-primary" href="<?php echo e(route('user.index')); ?>">Back</a>
                            </div>
                        </div>
                    </div>

                    <form method="POST" action="<?php echo e(route('user.update', $user->id)); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>
                    
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name"><strong>Name:</strong></label>
                                    <input type="text" name="name" value="<?php echo e($user->name); ?>" placeholder="Name" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jenis_kelamin"><strong>Jenis Kelamin:</strong></label>
                                    <select name="jenis_kelamin" class="form-control">
                                        <option value="" <?php echo e($user->jenis_kelamin === '' ? 'selected' : ''); ?>>-- Pilih Jenis Kelamin --</option>
                                        <option value="Laki-laki" <?php echo e($user->jenis_kelamin === 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                                        <option value="Perempuan" <?php echo e($user->jenis_kelamin === 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bio"><strong>Bio:</strong></label>
                                    <input type="text" name="bio" value="<?php echo e($user->bio); ?>" placeholder="Bio" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nomor_hp"><strong>Nomor Telepon:</strong></label>
                                    <input type="text" name="nomor_hp" value="<?php echo e($user->nomor_hp); ?>" placeholder="Nomor Telepon" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email"><strong>Email:</strong></label>
                                    <input type="text" name="email" value="<?php echo e($user->email); ?>" placeholder="Email" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="foto"><strong>Upload Foto:</strong></label>
                                    <input type="file" name="foto" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-12 text-center mt-5">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/user/edit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container-fluid">
            <div class="card mb-0">
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col">
                            <h5 class="card-title fw-semibold mb-4 d-inline">Peserta Management</h5>
                        </div>
                        <div class="col d-flex justify-content-end">
                            <a href="<?php echo e(route('peserta.create')); ?>" class="btn btn-sm btn-success me-2"><i class="bi bi-plus"></i> Create</a>
                            <a href="<?php echo e(route('peserta.cetak')); ?>" class="btn btn-sm btn-warning ml-2"><i class="bi bi-printer"></i> Cetak</a>
                        </div>
                    </div>
                    <table class="table table-striped" style="width:100%" id="example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Peserta</th>
                                <th>Judul</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($peserta->nama_peserta); ?></td>
                                <td><?php echo e($peserta->judul); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-info" href="<?php echo e(route('peserta.show', $peserta->id)); ?>">Show</a>
                                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('peserta.edit', $peserta->id)); ?>">Edit</a>
                                    <form action="<?php echo e(route('peserta.destroy', $peserta->id)); ?>" method="POST" onsubmit="return confirm('Yakin Untuk Menghapus Data ?')" class="d-inline">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/peserta/index.blade.php ENDPATH**/ ?>
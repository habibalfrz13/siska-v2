

<?php $__env->startSection('title', 'Kelola Materi - ' . $module->title); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('kelas.index')); ?>">Kelas</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.modules.index', $kelas->id)); ?>"><?php echo e(Str::limit($kelas->judul, 20)); ?></a></li>
            <li class="breadcrumb-item active"><?php echo e(Str::limit($module->title, 20)); ?></li>
        </ol>
    </nav>

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Kelola Materi</h4>
            <p class="text-muted mb-0">Modul: <?php echo e($module->title); ?></p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('admin.modules.index', $kelas->id)); ?>" class="btn btn-soft-secondary">
                <i class="bi bi-arrow-left me-2"></i>Kembali
            </a>
            <a href="<?php echo e(route('admin.materials.create', $module->id)); ?>" class="btn btn-gradient-primary">
                <i class="bi bi-plus-lg me-2"></i>Tambah Materi
            </a>
        </div>
    </div>

    <!-- Materials List -->
    <div class="modern-card">
        <div class="card-body">
            <?php if($materials->isEmpty()): ?>
                <div class="text-center py-5">
                    <i class="bi bi-collection-play display-1 text-muted mb-3 d-block"></i>
                    <h5>Belum Ada Materi</h5>
                    <p class="text-muted">Klik tombol "Tambah Materi" untuk membuat materi pertama.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th width="60">No</th>
                                <th>Judul Materi</th>
                                <th width="100">Tipe</th>
                                <th width="100">Durasi</th>
                                <th width="100">Status</th>
                                <th width="150">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="badge bg-secondary"><?php echo e($material->order); ?></span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="material-type-icon">
                                            <i class="bi <?php echo e($material->type_icon); ?>"></i>
                                        </div>
                                        <div>
                                            <div class="fw-semibold"><?php echo e($material->title); ?></div>
                                            <?php if($material->type === 'video' && $material->video_url): ?>
                                                <small class="text-muted"><?php echo e(Str::limit($material->video_url, 40)); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo e($material->type_label); ?></span>
                                </td>
                                <td>
                                    <?php if($material->duration): ?>
                                        <?php echo e($material->formatted_duration); ?>

                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($material->is_published): ?>
                                        <span class="badge bg-success">Published</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Draft</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.materials.edit', $material->id)); ?>" 
                                           class="btn btn-sm btn-soft-warning" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-soft-danger" 
                                                data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($material->id); ?>"
                                                title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <!-- Delete Modal -->
                            <div class="modal fade" id="deleteModal<?php echo e($material->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Konfirmasi Hapus</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Anda yakin ingin menghapus materi <strong><?php echo e($material->title); ?></strong>?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            <form action="<?php echo e(route('admin.materials.destroy', $material->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Hapus</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.material-type-icon {
    width: 36px;
    height: 36px;
    background: rgba(65, 84, 241, 0.1);
    color: var(--primary, #4154f1);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siskav2\resources\views/dashboard/admin/materials/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Tambah Kelas Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Header -->
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('kelas.index')); ?>">Kelas</a></li>
            <li class="breadcrumb-item active">Tambah Baru</li>
        </ol>
    </nav>

    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="modern-card">
                <div class="card-header bg-gradient-primary text-white">
                    <h5 class="mb-0 fw-semibold">
                        <i class="bi bi-plus-circle me-2"></i>Tambah Kelas Baru
                    </h5>
                    <p class="mb-0 opacity-75 small">Lengkapi informasi kelas di bawah ini</p>
                </div>
                <div class="card-body p-4">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><i class="bi bi-exclamation-triangle me-2"></i>Terjadi Kesalahan:</strong>
                            <ul class="mb-0 mt-2">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('kelas.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row g-4">
                            <!-- Left Column -->
                            <div class="col-lg-6">
                                <h6 class="fw-bold text-primary mb-3">
                                    <i class="bi bi-info-circle me-2"></i>Informasi Dasar
                                </h6>
                                
                                <div class="mb-3">
                                    <label for="judul" class="form-label">Judul Kelas <span class="text-danger">*</span></label>
                                    <input type="text" name="judul" id="judul" 
                                           class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           placeholder="Contoh: Belajar Web Development"
                                           value="<?php echo e(old('judul')); ?>" required>
                                    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="id_kategori" class="form-label">Kategori <span class="text-danger">*</span></label>
                                        <select name="id_kategori" id="id_kategori" 
                                                class="form-select <?php $__errorArgs = ['id_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Pilih Kategori</option>
                                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kategori->id); ?>" <?php echo e(old('id_kategori') == $kategori->id ? 'selected' : ''); ?>>
                                                    <?php echo e($kategori->nama_kategori); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="id_vendor" class="form-label">Vendor <span class="text-danger">*</span></label>
                                        <select name="id_vendor" id="id_vendor" 
                                                class="form-select <?php $__errorArgs = ['id_vendor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Pilih Vendor</option>
                                            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($vendor->id); ?>" <?php echo e(old('id_vendor') == $vendor->id ? 'selected' : ''); ?>>
                                                    <?php echo e($vendor->vendor); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_vendor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row g-3 mt-2">
                                    <div class="col-md-6">
                                        <label for="kuota" class="form-label">Kuota Peserta <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="bi bi-people"></i></span>
                                            <input type="number" name="kuota" id="kuota" 
                                                   class="form-control <?php $__errorArgs = ['kuota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                   placeholder="50" min="1"
                                                   value="<?php echo e(old('kuota')); ?>" required>
                                        </div>
                                        <?php $__errorArgs = ['kuota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="pelaksanaan" class="form-label">Tanggal Pelaksanaan <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
                                            <input type="date" name="pelaksanaan" id="pelaksanaan" 
                                                   class="form-control <?php $__errorArgs = ['pelaksanaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   value="<?php echo e(old('pelaksanaan')); ?>" required>
                                        </div>
                                        <?php $__errorArgs = ['pelaksanaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="mb-3 mt-3">
                                    <label for="deskripsi" class="form-label">Deskripsi Kelas</label>
                                    <textarea name="deskripsi" id="deskripsi" rows="5" 
                                              class="form-control <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              placeholder="Jelaskan tentang kelas ini, apa yang akan dipelajari, dll."><?php echo e(old('deskripsi')); ?></textarea>
                                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Right Column -->
                            <div class="col-lg-6">
                                <h6 class="fw-bold text-primary mb-3">
                                    <i class="bi bi-currency-dollar me-2"></i>Harga & Media
                                </h6>

                                <div class="mb-3">
                                    <label for="harga" class="form-label">Harga Kelas <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="number" name="harga" id="harga" 
                                               class="form-control <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               placeholder="250000" min="0"
                                               value="<?php echo e(old('harga')); ?>" required>
                                    </div>
                                    <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <small class="text-muted">Masukkan 0 untuk kelas gratis</small>
                                </div>

                                <div class="mb-3">
                                    <label for="foto" class="form-label">Foto Cover <span class="text-danger">*</span></label>
                                    <div class="upload-area" onclick="document.getElementById('foto').click()">
                                        <input type="file" name="foto" id="foto" accept="image/*" 
                                               class="d-none <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               onchange="previewImage(this)" required>
                                        <div class="upload-placeholder" id="upload-placeholder">
                                            <i class="bi bi-cloud-arrow-up display-4 text-muted"></i>
                                            <p class="mb-0 text-muted">Klik untuk upload gambar</p>
                                            <small class="text-muted">JPG, PNG, SVG (maks. 2MB)</small>
                                        </div>
                                        <img id="preview-image" class="d-none" style="max-width: 100%; max-height: 200px; border-radius: 8px;">
                                    </div>
                                    <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Preview Card -->
                                <div class="preview-card mt-4">
                                    <h6 class="fw-bold mb-3"><i class="bi bi-eye me-2"></i>Preview</h6>
                                    <div class="preview-content">
                                        <div class="preview-image">
                                            <img id="card-preview-image" src="https://via.placeholder.com/300x160?text=Preview" alt="Preview">
                                        </div>
                                        <div class="preview-body">
                                            <span class="preview-category" id="preview-category">Kategori</span>
                                            <h6 class="preview-title" id="preview-title">Judul Kelas</h6>
                                            <div class="preview-price" id="preview-price">Rp 0</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('kelas.index')); ?>" class="btn btn-secondary">
                                <i class="bi bi-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-gradient-primary">
                                <i class="bi bi-check-lg me-2"></i>Simpan Kelas
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.card-header.bg-gradient-primary {
    background: linear-gradient(135deg, #4154f1 0%, #764ba2 100%);
    padding: 1.5rem;
}

.upload-area {
    border: 2px dashed var(--border-color, #dee2e6);
    border-radius: 12px;
    padding: 2rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    background: var(--bg-light, #f8f9fa);
}

.upload-area:hover {
    border-color: var(--primary, #4154f1);
    background: rgba(65, 84, 241, 0.05);
}

.preview-card {
    background: var(--bg-light, #f8f9fa);
    border-radius: 12px;
    padding: 1rem;
}

.preview-content {
    background: #fff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.preview-image {
    height: 100px;
    overflow: hidden;
}

.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.preview-body {
    padding: 1rem;
}

.preview-category {
    font-size: 0.7rem;
    color: var(--primary, #4154f1);
    text-transform: uppercase;
    font-weight: 600;
}

.preview-title {
    font-size: 0.9rem;
    margin: 0.25rem 0;
    color: var(--text-primary, #1e293b);
}

.preview-price {
    font-weight: 700;
    color: var(--primary, #4154f1);
    font-size: 0.9rem;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function previewImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            document.getElementById('preview-image').src = e.target.result;
            document.getElementById('preview-image').classList.remove('d-none');
            document.getElementById('upload-placeholder').classList.add('d-none');
            document.getElementById('card-preview-image').src = e.target.result;
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

// Live preview updates
document.getElementById('judul').addEventListener('input', function() {
    document.getElementById('preview-title').textContent = this.value || 'Judul Kelas';
});

document.getElementById('harga').addEventListener('input', function() {
    const harga = parseInt(this.value) || 0;
    document.getElementById('preview-price').textContent = 'Rp ' + harga.toLocaleString('id-ID');
});

document.getElementById('id_kategori').addEventListener('change', function() {
    const selectedText = this.options[this.selectedIndex].text;
    document.getElementById('preview-category').textContent = selectedText || 'Kategori';
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siskav2\resources\views/dashboard/kelas/create.blade.php ENDPATH**/ ?>
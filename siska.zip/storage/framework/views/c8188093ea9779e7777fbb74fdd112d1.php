

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <img src="<?php echo e(asset('template/dashboard')); ?>/images/logos/4.svg" class="card-img-top"
            style="object-fit: cover; height:70px" alt="Gambar Konten">
    </div>

    <div class="card mt-2">
        <div class="card-body">
            <div class="card nota-container">
                <div class="card-header nota-header">
                    <h5 class="card-title text-primary">Konfirmasi Pembayaran</h5>
                    <p class="text-end"></p>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" id="datatable">
                        <thead>
                            <tr>
                                <th>Kelas</th>
                                <th>Harga</th>
                                <th>Status</th>
                                <th width="150">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                           
                                <tr>
                                    <td><?php echo e($transaksi->kelas->judul); ?></td>
                                    <td><?php echo e($transaksi->jumlah_pembayaran); ?></td>
                                    <td><?php echo e($transaksi->status_pembayaran); ?></td>
                                    <td>
                                        <?php if($transaksi->status_pembayaran != 'Gagal'): ?>
                                            <button class="btn btn-success btn-sm" id="pay-button">Bayar</button>
                                            <a href="<?php echo e(route('transaksi.batalkan', $transaksi->id)); ?>" class="btn btn-danger btn-sm mt-1">Batalkan</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                           
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="d-flex justify-content-start my-3">
                
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    document.getElementById('pay-button').onclick = function(){
        // SnapToken acquired from previous step
        snap.pay('<?php echo e($transaksi->snap_token); ?>', {
            // Optional
            onSuccess: function(result){
                // Redirect to the desired route after successful payment
                window.location.href = '<?php echo e(route('transaksi.sukses', $transaksi->id)); ?>';
            },
            // Optional
            onPending: function(result){
                /* You may add your own js here, this is just an example */
                document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
            },
            // Optional
            onError: function(result){
                /* You may add your own js here, this is just an example */
                document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
            }
        });
    };
</script>


<?php $__env->stopSection(); ?>


   

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/transaksi/userIndex.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="content-wrapper">
        <div class="row">
            <div class="card shadow-lg">
                <div class="card-body">
                    <div class="col-md-12 grid-margin">
                        <div class="row">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-10">
                                        <h4>Create New Vendor</h4>
                                    </div>
                                    <div class="col-lg-2 text-right">
                                        <a class="btn btn-primary mb-2" href="<?php echo e(route('vendor.index')); ?>"> Back </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form method="POST" action="<?php echo e(route('vendor.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="vendor">Nama Vendor:</label>
                                        <input type="text" name="vendor" class="form-control" placeholder="Nama Vendor">
                                    </div>
                                </div>
                                <div class="col-md-12 text-center mt-4">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siskav2\resources\views/dashboard/vendor/create.blade.php ENDPATH**/ ?>
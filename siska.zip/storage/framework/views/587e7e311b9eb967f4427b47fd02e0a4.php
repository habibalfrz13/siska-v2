

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="container-fluid">
    <div class="card mb-0">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col">
                    <h5 class="card-title fw-semibold mb-4 d-inline">Kelas Management</h5>
                </div>
                <div class="col d-flex justify-content-end">
                    <a href="<?php echo e(route('kelas.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus"></i> Buat Kelas</a>
                </div>
            </div>
            <table class="table table-striped" style="width:100%" id="example">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Waktu Pelaksanaan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kelas->status == 'Aktif'): ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($kelas->judul); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($kelas->pelaksanaan)->format('d M Y')); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-info" href="<?php echo e(route('myclass.show', $kelas->id)); ?>">Detail</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/myclass/index.blade.php ENDPATH**/ ?>
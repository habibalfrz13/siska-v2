

<?php $__env->startSection('content'); ?>


     <!-- Informasi Cuaca -->
     <?php if(auth()->user()->id_role == 1): ?>
    <div class="weather-widget">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0 fw-bold">Informasi Cuaca Hari Ini</h5>
            </div>
            <div class="card-body">
                <div class="weather-info">
                    <p class="weather-data">
                        Suhu: <span id="temperature"></span>&deg;C
                        <i class="bi bi-clouds-fill ms-2"></i>
                    </p>
                    <p class="weather-data">
                        Kelembaban: <span id="humidity"></span>%
                        <i class="bi bi-droplet-fill ms-2"></i>
                    </p>
                    <p class="weather-data">
                        Kecepatan Angin: <span id="wind-speed"></span> m/s
                        <i class="bi bi-speedometer ms-2"></i>
                    </p>
                    <p class="weather-data">
                        Deskripsi: <span id="description"></span>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>


    <!-- Informasi Sertifikasi -->
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <!-- Baris dalam Card -->
                    <div class="row">
                        <!-- Kolom Kiri -->
                        <div class="col-md-6">
                            <h5 class="card-title fw-semibold">Informasi Sertifikasi</h5>
                            <h4 class="fw-semibold mb-3">Total Kelas: <?php echo e($total); ?></h4>
                            <div class="d-flex align-items-center">
                                <span class="me-2"><i class="ti ti-calendar text-primary fs-4"></i></span>
                                <div>
                                    <p class="mb-0">Sertifikasi Aktif: <span class="text-success"><?php echo e($aktif); ?></span></p>
                                    <p class="mb-0">Sertifikasi Tidak Aktif: <span class="text-danger"><?php echo e($noaktif); ?></span></p>
                                </div>
                            </div>
                        </div>
                        <!-- Kolom Kanan -->
                        <div class="col-md-6">
                            <div style="width: 150px; height: 150px;">
                                <canvas id="certificationChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Daftar Sertifikasi -->
    <div class="row mt-4">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-4">Daftar Sertifikasi</h5>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Sertifikasi</th>
                                    <th>Pelaksanaan</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $certification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($certification->judul); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($certification->pelaksanaan)->format('d M Y')); ?></td>
                                        <td>
                                            <?php if($certification->status == 'Aktif'): ?>
                                                <span class="badge bg-success"><?php echo e($certification->status); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-danger"><?php echo e($certification->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Penjualan Kelas yang Berhasil -->
    <?php if(auth()->user()->id_role == 1): ?>
    <div class="row mt-4" style="display: flex; align-items: stretch;">
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title fw-semibold">Laporan Penjualan Kelas Berhasil</h5>
                    <p class="mb-0">Total Penjualan: <h3><span class="text-success"><?php echo e($successfulSales); ?></span></h3></p>
                    <div style="width: 400px; height: 200px;">
                        <canvas id="salesChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    
        <!-- Total Pendapatan dari Transaksi yang Berstatus Berhasil -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <div class="row">
                        <div class="col-8">
                            <h5 class="card-title fw-semibold">Laporan Transaksi Berhasil</h5> 
                        </div> 
                        <div class="col-4">
                            <a href="<?php echo e(route('transaksi.cetaksuccess')); ?>" class="btn btn-sm btn-warning mx-1"><i class="bi bi-printer"></i> Cetak</a>
                        </div>
                    </div>
                    <p class="mb-0">Total Pendapatan: <h3><span class="text-success"><?php echo e('Rp ' . number_format($totalRevenue, 0, ',', '.')); ?></span></h3></p> 
                    <div style="width: 400px; height: 200px;">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Certification Chart
        const certificationCtx = document.getElementById('certificationChart').getContext('2d');
        const certificationChart = new Chart(certificationCtx, {
            type: 'pie',
            data: {
                labels: ['Aktif', 'Tidak Aktif'],
                datasets: [{
                    label: 'Sertifikasi',
                    data: [<?php echo e($aktif); ?>, <?php echo e($noaktif); ?>],
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(255, 99, 132, 0.2)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // Sales Chart
        const salesCtx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(salesCtx, {
            type: 'bar',
            data: {
                labels: ['Penjualan Berhasil'],
                datasets: [{
                    label: 'Total Penjualan',
                    data: [<?php echo e($successfulSales); ?>],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // Revenue Chart
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        const revenueChart = new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: ['Total Pendapatan'],
                datasets: [{
                    label: 'Pendapatan',
                    data: [<?php echo e($totalRevenue); ?>],
                    backgroundColor: 'rgba(255, 206, 86, 0.2)',
                    borderColor: 'rgba(255, 206, 86, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // Weather API
        const apiKey = '2bb008a2dee92d080615c7975ccf5bfa';
        const city = 'Padang';
        const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

        fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            console.log(data);
            document.getElementById('temperature').textContent = data.main.temp;
            document.getElementById('humidity').textContent = data.main.humidity;
            document.getElementById('wind-speed').textContent = data.wind.speed;
            document.getElementById('description').textContent = data.weather[0].description;
        })
        .catch(error => console.log('Error fetching data:', error));

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/home.blade.php ENDPATH**/ ?>
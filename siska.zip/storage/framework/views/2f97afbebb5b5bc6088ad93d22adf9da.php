

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container-fluid">
            <div class="card mb-0 ">
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col">
                            <h5 class="card-title fw-semibold mb-4 d-inline">Data Vendor</h5>
                        </div>
                        <div class="col d-flex justify-content-end">
                            <a href="<?php echo e(route('vendor.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus"></i>
                                Tambah</a>
                        </div>
                    </div>
                    <table class="table table-striped" style="width:100%" id="example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Vendor</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($vendor->vendor); ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-info" href="<?php echo e(route('vendor.show', $vendor->id)); ?>">Show</a>
                                        <a class="btn btn-sm btn-primary" href="<?php echo e(route('vendor.edit', $vendor->id)); ?>">Edit</a>
                                        <form action="<?php echo e(route('vendor.destroy', $vendor->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this item?')" class="d-inline">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siska\resources\views/dashboard/vendor/index.blade.php ENDPATH**/ ?>
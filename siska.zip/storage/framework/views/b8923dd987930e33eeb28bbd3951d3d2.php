<nav class="sidebar-nav scroll-sidebar" data-simplebar="">
    <ul id="sidebarnav">
        <!-- Dashboard -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Beranda</span>
        </li>


        
        <?php if(Auth::user()->id_role == '1'): ?>
        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('home')); ?>" aria-expanded="false">
                <span>
                    <i class="ti ti-layout-dashboard"></i>
                </span>
                <span class="hide-menu">Dashboard</span>
            </a>
        </li>

        <!-- Konten -->
        <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Konten</span>
        </li>

        <!-- User -->
        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('kategori.index')); ?>" aria-expanded="false">
                <span>
                    <i class="bi bi-bookmark-star"></i>
                </span>
                <span class="hide-menu">Kategori</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('vendor.index')); ?>" aria-expanded="false">
                <span>
                    <i class="bi bi-building-check"></i>
                </span>
                <span class="hide-menu">Vendor</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('kelas.index')); ?>" aria-expanded="false">
                <span>
                    <i class="bi bi-journal-bookmark"></i>
                </span>
                <span class="hide-menu">Kelas</span>
            </a>
        </li>

        

        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('transaksi.index')); ?>" aria-expanded="false">
                <span>
                    <i class="bi bi-bank"></i>
                </span>
                <span class="hide-menu">Transaksi</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('peserta.index')); ?>" aria-expanded="false">
                <span>
                    <i class="bi bi-person-lines-fill"></i>
                </span>
                <span class="hide-menu">Peserta</span>
            </a>
        </li>

        <!-- Kerajinan -->
        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('user.index')); ?>" aria-expanded="false">
                <span>
                    <i class="bi bi-postcard-heart-fill"></i>
                </span>
                <span class="hide-menu">Pengguna</span>
            </a>
        </li>

        
        <?php else: ?>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="<?php echo e(route('home')); ?>" aria-expanded="false">
                        <span>
                            <i class="ti ti-layout-dashboard"></i>
                        </span>
                        <span class="hide-menu">Dashboard</span>
                    </a>
                </li>
                <!-- User -->
                <li class="sidebar-item">
                    <a class="sidebar-link" href="<?php echo e(route('kelas.userIndex')); ?>" aria-expanded="false">
                        <span>
                            <i class="bi bi-journal-bookmark"></i>
                        </span>
                        <span class="hide-menu">Class</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a class="sidebar-link" href="<?php echo e(route('myclass.userIndex')); ?>" aria-expanded="false">
                        <span>
                            <i class="bi bi-person-lines-fill"></i>
                        </span>
                        <span class="hide-menu">My Class</span>
                    </a>
                </li>            
        <?php endif; ?>
     
        
        
    </ul>
</nav>
<!-- End Sidebar navigation -->


<?php /**PATH C:\laragon\www\siska\resources\views/dashboard/sidebar.blade.php ENDPATH**/ ?>
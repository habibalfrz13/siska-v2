

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Kelas Saya</h4>
            <p class="text-muted mb-0">Kelola dan pantau progres kelas yang Anda ikuti</p>
        </div>
        <a href="<?php echo e(route('kelas.userIndex')); ?>" class="btn btn-gradient-primary">
            <i class="bi bi-plus-lg me-2"></i>Tambah Kelas
        </a>
    </div>

    <?php if($myclass->isEmpty()): ?>
    <!-- Empty State -->
    <div class="empty-state">
        <div class="empty-icon">
            <i class="bi bi-mortarboard"></i>
        </div>
        <h5>Belum Ada Kelas yang Diikuti</h5>
        <p>Anda belum terdaftar di kelas manapun. Mulai tingkatkan skill Anda sekarang!</p>
        <a href="<?php echo e(route('kelas.userIndex')); ?>" class="btn btn-gradient-primary">
            <i class="bi bi-search me-2"></i>Jelajahi Kelas
        </a>
    </div>
    <?php else: ?>
    <!-- Class Grid -->
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php $__currentLoopData = $myclass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $data = App\Models\Kelas::where('id', $class->kelas_id)->first();
        ?>
        <div class="col">
            <div class="myclass-card">
                <div class="myclass-image">
                    <img src="<?php echo e(url('images/galerikelas/'.$class->kelas->foto)); ?>" alt="<?php echo e($class->kelas->judul); ?>">
                    <span class="myclass-status <?php echo e($class->status == 'Aktif' ? 'active' : ($class->status == 'Pending' ? 'pending' : 'inactive')); ?>">
                        <?php if($class->status == 'Aktif'): ?>
                            <i class="bi bi-check-circle me-1"></i>
                        <?php elseif($class->status == 'Pending'): ?>
                            <i class="bi bi-clock me-1"></i>
                        <?php else: ?>
                            <i class="bi bi-exclamation-circle me-1"></i>
                        <?php endif; ?>
                        <?php echo e($class->status); ?>

                    </span>
                </div>
                <div class="myclass-body">
                    <h5 class="myclass-title"><?php echo e($class->kelas->judul); ?></h5>
                    
                    <div class="myclass-info">
                        <div class="info-row">
                            <i class="bi bi-calendar3"></i>
                            <span><?php echo e(\Carbon\Carbon::parse($class->kelas->pelaksanaan)->format('d M Y')); ?></span>
                        </div>
                        <div class="info-row">
                            <i class="bi bi-building"></i>
                            <span><?php echo e($class->kelas->vendor->nama ?? 'SISKAE'); ?></span>
                        </div>
                    </div>
                    
                    <div class="myclass-actions">
                        <?php if($class->status == 'Aktif'): ?>
                            <a href="<?php echo e(route('learn.course', $class->kelas_id)); ?>" class="btn btn-soft-success flex-grow-1">
                                <i class="bi bi-play-circle me-2"></i>Masuk Kelas
                            </a>
                            <button type="button" class="btn btn-soft-primary" 
                                    data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($class->id); ?>">
                                <i class="bi bi-info-circle"></i>
                            </button>
                        <?php elseif($class->status == 'Tidak Aktif'): ?>
                            <a href="<?php echo e(route('transaksi.userIndex', $class->id)); ?>" class="btn btn-soft-warning flex-grow-1">
                                <i class="bi bi-credit-card me-2"></i>Bayar Sekarang
                            </a>
                        <?php elseif($class->status == 'Pending'): ?>
                            <button type="button" class="btn btn-soft-primary flex-grow-1" 
                                    data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($class->id); ?>">
                                <i class="bi bi-hourglass-split me-2"></i>Menunggu Pembayaran
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detail Modal -->
        <div class="modal fade" id="detailModal<?php echo e($class->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <div>
                            <h5 class="modal-title">
                                <i class="bi bi-info-circle me-2"></i>Detail Kelas
                            </h5>
                            <small class="opacity-75"><?php echo e($class->kelas->judul); ?></small>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="registration-summary">
                            <div class="summary-item">
                                <span class="text-muted">Judul Kelas</span>
                                <span class="fw-semibold"><?php echo e($class->kelas->judul); ?></span>
                            </div>
                            <div class="summary-item">
                                <span class="text-muted">Kategori</span>
                                <span><?php echo e($class->kelas->kategori->nama ?? '-'); ?></span>
                            </div>
                            <div class="summary-item">
                                <span class="text-muted">Vendor</span>
                                <span><?php echo e($class->kelas->vendor->nama ?? 'SISKAE'); ?></span>
                            </div>
                            <div class="summary-item">
                                <span class="text-muted">Kuota</span>
                                <span><?php echo e($class->kelas->kuota); ?> Peserta</span>
                            </div>
                            <div class="summary-item">
                                <span class="text-muted">Pelaksanaan</span>
                                <span><?php echo e(\Carbon\Carbon::parse($class->kelas->pelaksanaan)->format('d M Y')); ?></span>
                            </div>
                            <div class="summary-item">
                                <span class="text-muted">Status Anda</span>
                                <span class="status-badge <?php echo e($class->status == 'Aktif' ? 'success' : ($class->status == 'Pending' ? 'warning' : 'danger')); ?>">
                                    <?php echo e($class->status); ?>

                                </span>
                            </div>
                        </div>
                        
                        <?php if($class->kelas->deskripsi): ?>
                        <div class="mt-3">
                            <h6 class="fw-semibold mb-2">Deskripsi</h6>
                            <p class="text-muted small mb-0"><?php echo e($class->kelas->deskripsi); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">
                            <i class="bi bi-x-lg me-1"></i>Tutup
                        </button>
                        <?php if($class->status == 'Aktif'): ?>
                        <a href="<?php echo e(route('learn.course', $class->kelas_id)); ?>" class="btn btn-gradient-primary">
                            <i class="bi bi-play-circle me-1"></i>Masuk Kelas
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siskav2\resources\views/dashboard/myclass/userIndex.blade.php ENDPATH**/ ?>